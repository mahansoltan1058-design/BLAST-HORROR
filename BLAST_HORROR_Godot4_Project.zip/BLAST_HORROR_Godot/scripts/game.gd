extends Node3D
## BLAST HORROR - procedural first-person horror prototype for Godot 4.
const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const ENEMY_SCRIPT = preload("res://scripts/enemy.gd")
const PICKUP_SCRIPT = preload("res://scripts/pickup.gd")
const DOOR_SCRIPT = preload("res://scripts/door.gd")

var player: CharacterBody3D
var enemy: CharacterBody3D
var hud: CanvasLayer
var menu: Control
var message_label: Label
var keys_found := 0
var puzzle_solved := false
var game_started := false
var sound_volume := 0.7
var master_bus := 0
var ambience: AudioStreamPlayer
var scare_player: AudioStreamPlayer
var exit_door: Node3D
var hint_timer := 0.0

func _ready() -> void:
    randomize()
    _setup_audio()
    _build_world()
    _build_player()
    _build_enemy()
    _build_ui()
    _show_menu()
    _load_progress()

func _setup_audio() -> void:
    master_bus = AudioServer.get_bus_index("Master")
    ambience = AudioStreamPlayer.new()
    ambience.stream = load("res://audio/ambience.wav")
    ambience.volume_db = -15.0
    ambience.bus = "Master"
    add_child(ambience)
    ambience.play()
    scare_player = AudioStreamPlayer.new()
    scare_player.stream = load("res://audio/stinger.wav")
    scare_player.volume_db = -7.0
    add_child(scare_player)

func _mat(color: Color, roughness := 0.9, metallic := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    m.metallic = metallic
    return m

func _box(parent: Node3D, name: String, pos: Vector3, size: Vector3, material: Material, collision := true) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.name = name
    body.position = pos
    parent.add_child(body)
    var mesh := MeshInstance3D.new()
    var shape_mesh := BoxMesh.new()
    shape_mesh.size = size
    mesh.mesh = shape_mesh
    mesh.material_override = material
    body.add_child(mesh)
    if collision:
        var cs := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = size
        cs.shape = shape
        body.add_child(cs)
    return body

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color(0.006, 0.008, 0.014)
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.12, 0.13, 0.17)
    environment.ambient_light_energy = 0.18
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    environment.tonemap_exposure = 0.8
    env.environment = environment
    add_child(env)

    var house := Node3D.new()
    house.name = "AbandonedHouse"
    add_child(house)
    var floor_mat := _mat(Color(0.105, 0.095, 0.085))
    var wall_mat := _mat(Color(0.16, 0.155, 0.145))
    var dark_mat := _mat(Color(0.045, 0.05, 0.06))
    var wood_mat := _mat(Color(0.12, 0.065, 0.035))
    var floor := _box(house, "Floor", Vector3(0,-0.25,0), Vector3(28,0.5,28), floor_mat)
    # Main connected house shell; openings form a corridor and side rooms.
    _box(house,"NorthWall",Vector3(0,2,-14),Vector3(28,4,0.5),wall_mat)
    _box(house,"SouthWall",Vector3(0,2,14),Vector3(28,4,0.5),wall_mat)
    _box(house,"WestWall",Vector3(-14,2,0),Vector3(0.5,4,28),wall_mat)
    _box(house,"EastWall",Vector3(14,2,0),Vector3(0.5,4,28),wall_mat)
    # Room partitions with gaps.
    _box(house,"PartitionA1",Vector3(-5,2,-7),Vector3(0.5,4,10),wall_mat)
    _box(house,"PartitionA2",Vector3(5,2,-7),Vector3(0.5,4,10),wall_mat)
    _box(house,"PartitionB1",Vector3(-5,2,7),Vector3(0.5,4,10),wall_mat)
    _box(house,"PartitionB2",Vector3(5,2,7),Vector3(0.5,4,10),wall_mat)
    _box(house,"BackRoomWall",Vector3(0,2,-10),Vector3(10,4,0.5),wall_mat)
    _box(house,"FrontRoomWall",Vector3(0,2,10),Vector3(10,4,0.5),wall_mat)
    # Ceiling beams and scattered debris.
    for z in [-11,-6,-1,4,9]:
        _box(house,"CeilingBeam",Vector3(0,3.85,z),Vector3(27,0.18,0.22),dark_mat,false)
    for i in range(18):
        var x := randf_range(-11,11)
        var z := randf_range(-11,11)
        var debris := _box(house,"Debris",Vector3(x,-0.02,z),Vector3(randf_range(.2,.8),.08,randf_range(.2,.7)),wood_mat,false)
        debris.rotation.y = randf_range(0,PI)

    # Weak, warm practical lights leave most corners dark.
    for p in [Vector3(-9,2.7,-9),Vector3(8,2.7,-8),Vector3(-9,2.7,8),Vector3(8,2.7,8)]:
        var light := OmniLight3D.new()
        light.position = p
        light.light_color = Color(1.0,0.68,0.38)
        light.light_energy = 0.55
        light.omni_range = 6.0
        light.shadow_enabled = true
        add_child(light)

    # Decorative furniture silhouettes.
    _box(house,"BrokenTable",Vector3(-9,0.55,-3),Vector3(2.4,0.18,1.3),wood_mat)
    _box(house,"Cabinet",Vector3(9,1.1,2),Vector3(1.3,2.2,0.8),dark_mat)
    _box(house,"BedFrame",Vector3(-9,0.3,9),Vector3(3,0.25,2.2),wood_mat)
    _box(house,"Wardrobe",Vector3(9,1.2,-10),Vector3(2,2.4,0.9),dark_mat)

    # Doors and collectible keys.
    _make_door(Vector3(0,1.25,-9.6), "BasementDoor", true)
    _make_door(Vector3(0,1.25,9.6), "ExitDoor", true)
    exit_door = get_node_or_null("ExitDoor")
    _make_pickup(Vector3(-9,0.8,-7), "Key", "Basement Key")
    _make_pickup(Vector3(9,0.8,9), "Key", "Exit Key")
    _make_pickup(Vector3(0,0.65,0), "Fuse", "Fuse")
    _make_puzzle_console(Vector3(9,0.8,-5))

    # Fog and low-cost atmosphere.
    var fog_env := environment
    fog_env.fog_enabled = true
    fog_env.fog_light_color = Color(0.12,0.13,0.16)
    fog_env.fog_density = 0.025

func _make_door(pos: Vector3, door_name: String, locked: bool) -> void:
    var door := StaticBody3D.new()
    door.name = door_name
    door.position = pos
    door.set_script(DOOR_SCRIPT)
    door.set("is_locked", locked)
    add_child(door)
    var mesh := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(1.8,2.5,0.16)
    mesh.mesh = bm
    mesh.material_override = _mat(Color(0.105,0.052,0.028))
    door.add_child(mesh)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(1.8,2.5,0.16)
    cs.shape = bs
    door.add_child(cs)
    door.add_to_group("interactable")
    door.set_meta("prompt", "در")

func _make_pickup(pos: Vector3, kind: String, label_text: String) -> void:
    var item := Area3D.new()
    item.position = pos
    item.set_script(PICKUP_SCRIPT)
    item.set("item_type", kind)
    item.set("display_name", label_text)
    item.add_to_group("interactable")
    add_child(item)
    var mesh := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.18
    sphere.height = 0.36
    mesh.mesh = sphere
    mesh.material_override = _mat(Color(0.95,0.62,0.12),0.35,0.3)
    item.add_child(mesh)
    var cs := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 0.65
    cs.shape = shape
    item.add_child(cs)
    item.set_meta("prompt", label_text)

func _make_puzzle_console(pos: Vector3) -> void:
    var console := StaticBody3D.new()
    console.name = "FuseConsole"
    console.position = pos
    add_child(console)
    var mesh := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.8,1.1,0.45)
    mesh.mesh = bm
    mesh.material_override = _mat(Color(0.07,0.08,0.075),0.7,0.4)
    console.add_child(mesh)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(0.8,1.1,0.45)
    cs.shape = bs
    console.add_child(cs)
    console.add_to_group("interactable")
    console.set_meta("prompt","جعبه فیوز")

func _build_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0,0.15,11.5)
    player.set_script(PLAYER_SCRIPT)
    add_child(player)
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.32
    capsule.height = 1.65
    collision.shape = capsule
    collision.position.y = 0.82
    player.add_child(collision)
    var camera := Camera3D.new()
    camera.name = "Camera3D"
    camera.position.y = 1.52
    camera.current = true
    camera.fov = 78
    player.add_child(camera)
    var flashlight := SpotLight3D.new()
    flashlight.name = "Flashlight"
    flashlight.position = Vector3(0,0,-0.15)
    flashlight.rotation.x = deg_to_rad(-4)
    flashlight.light_color = Color(0.82,0.9,1.0)
    flashlight.light_energy = 2.1
    flashlight.spot_range = 19
    flashlight.spot_angle = 38
    flashlight.shadow_enabled = true
    camera.add_child(flashlight)
    player.set("game", self)

func _build_enemy() -> void:
    enemy = CharacterBody3D.new()
    enemy.name = "The_Stalker"
    enemy.position = Vector3(-8,0.1,-10)
    enemy.set_script(ENEMY_SCRIPT)
    add_child(enemy)
    var col := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.48
    cap.height = 2.15
    col.shape = cap
    col.position.y = 1.05
    enemy.add_child(col)
    var body := MeshInstance3D.new()
    var cm := CapsuleMesh.new()
    cm.radius = 0.48
    cm.height = 2.15
    body.mesh = cm
    var em := _mat(Color(0.018,0.012,0.02),0.95)
    body.material_override = em
    body.position.y = 1.05
    enemy.add_child(body)
    var eyes := MeshInstance3D.new()
    var eye_mesh := SphereMesh.new()
    eye_mesh.radius = 0.07
    eye_mesh.height = 0.14
    eyes.mesh = eye_mesh
    eyes.material_override = _mat(Color(0.8,0.015,0.01),0.25,0.0)
    eyes.position = Vector3(0,1.55,-0.35)
    enemy.add_child(eyes)
    enemy.set("target", player)

func _build_ui() -> void:
    hud = CanvasLayer.new()
    hud.name = "HUD"
    add_child(hud)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_PASS
    hud.add_child(root)

    var cross := Label.new()
    cross.text = "+"
    cross.add_theme_font_size_override("font_size",24)
    cross.add_theme_color_override("font_color",Color(0.8,0.82,0.85,0.7))
    cross.anchor_left = 0.5
    cross.anchor_top = 0.5
    cross.anchor_right = 0.5
    cross.anchor_bottom = 0.5
    cross.position = Vector2(-8,-18)
    root.add_child(cross)

    message_label = Label.new()
    message_label.text = ""
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.anchor_left = 0.2
    message_label.anchor_right = 0.8
    message_label.anchor_top = 0.12
    message_label.add_theme_font_size_override("font_size",22)
    message_label.add_theme_color_override("font_color",Color(1,0.83,0.65))
    root.add_child(message_label)

    var status := Label.new()
    status.name = "Status"
    status.text = "BLAST HORROR  |  کلیدها: 0/2"
    status.position = Vector2(20,18)
    status.add_theme_font_size_override("font_size",18)
    status.add_theme_color_override("font_color",Color(0.82,0.82,0.82))
    root.add_child(status)

    _add_button(root,"چراغ‌قوه",Vector2(-190,-150),Vector2(150,58),Callable(self,"_toggle_flashlight"),true)
    _add_button(root,"تعامل",Vector2(-190,-80),Vector2(150,58),Callable(self,"_interact"),true)
    var flash_btn := root.get_node("چراغ‌قوه") as Button
    flash_btn.anchor_left = 1; flash_btn.anchor_right = 1; flash_btn.anchor_top = 1; flash_btn.anchor_bottom = 1
    var interact_btn := root.get_node("تعامل") as Button
    interact_btn.anchor_left = 1; interact_btn.anchor_right = 1; interact_btn.anchor_top = 1; interact_btn.anchor_bottom = 1

    var joy := Control.new()
    joy.name = "VirtualJoystick"
    joy.set_script(load("res://scripts/joystick.gd"))
    joy.position = Vector2(36,0)
    joy.anchor_top = 1
    joy.anchor_bottom = 1
    joy.offset_top = -205
    joy.offset_bottom = -25
    joy.offset_left = 20
    joy.offset_right = 200
    root.add_child(joy)

    var pause_btn := Button.new()
    pause_btn.text = "Ⅱ"
    pause_btn.position = Vector2(-85,20)
    pause_btn.anchor_left = 1
    pause_btn.anchor_right = 1
    pause_btn.size = Vector2(64,56)
    pause_btn.add_theme_font_size_override("font_size",24)
    pause_btn.pressed.connect(_pause_game)
    root.add_child(pause_btn)

    menu = Control.new()
    menu.name = "Menu"
    menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(menu)

func _add_button(parent: Control, title: String, pos: Vector2, size: Vector2, callback: Callable, bottom_right := false) -> void:
    var b := Button.new()
    b.name = title
    b.text = title
    b.size = size
    b.add_theme_font_size_override("font_size",18)
    b.add_theme_color_override("font_color",Color(1,1,1))
    b.add_theme_stylebox_override("normal",_button_style(Color(0.12,0.12,0.14,0.85)))
    b.add_theme_stylebox_override("pressed",_button_style(Color(0.35,0.08,0.07,0.95)))
    if bottom_right:
        b.position = pos
    b.pressed.connect(callback)
    parent.add_child(b)

func _button_style(c: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = c
    s.corner_radius_top_left = 12
    s.corner_radius_top_right = 12
    s.corner_radius_bottom_left = 12
    s.corner_radius_bottom_right = 12
    s.border_width_left = 1
    s.border_width_right = 1
    s.border_width_top = 1
    s.border_width_bottom = 1
    s.border_color = Color(0.45,0.4,0.38,0.8)
    return s

func _show_menu() -> void:
    for c in menu.get_children():
        c.queue_free()
    var shade := ColorRect.new()
    shade.color = Color(0.005,0.006,0.01,0.92)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu.add_child(shade)
    var title := Label.new()
    title.text = "BLAST HORROR"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.anchor_left = 0.1
    title.anchor_right = 0.9
    title.anchor_top = 0.22
    title.add_theme_font_size_override("font_size",54)
    title.add_theme_color_override("font_color",Color(0.72,0.06,0.045))
    menu.add_child(title)
    var subtitle := Label.new()
    subtitle.text = "THE HOUSE REMEMBERS"
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.anchor_left = 0.1
    subtitle.anchor_right = 0.9
    subtitle.anchor_top = 0.34
    subtitle.add_theme_font_size_override("font_size",16)
    subtitle.add_theme_color_override("font_color",Color(0.65,0.65,0.68))
    menu.add_child(subtitle)
    _menu_button(menu,"شروع بازی",0.47,Callable(self,"_start_game"))
    _menu_button(menu,"تنظیمات صدا",0.59,Callable(self,"_show_settings"))
    _menu_button(menu,"ادامه بازی",0.71,Callable(self,"_continue_game"))

func _menu_button(parent: Control, label: String, y: float, cb: Callable) -> void:
    var b := Button.new()
    b.text = label
    b.anchor_left = 0.35
    b.anchor_right = 0.65
    b.anchor_top = y
    b.anchor_bottom = y
    b.offset_top = 0
    b.offset_bottom = 54
    b.add_theme_font_size_override("font_size",21)
    b.add_theme_stylebox_override("normal",_button_style(Color(0.16,0.045,0.04,0.95)))
    b.pressed.connect(cb)
    parent.add_child(b)

func _show_settings() -> void:
    for c in menu.get_children():
        c.queue_free()
    var shade := ColorRect.new()
    shade.color = Color(0.005,0.006,0.01,0.94)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu.add_child(shade)
    var title := Label.new()
    title.text = "تنظیمات صدا"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.anchor_left = 0.2
    title.anchor_right = 0.8
    title.anchor_top = 0.3
    title.add_theme_font_size_override("font_size",32)
    menu.add_child(title)
    var slider := HSlider.new()
    slider.anchor_left = 0.25
    slider.anchor_right = 0.75
    slider.anchor_top = 0.46
    slider.offset_bottom = 36
    slider.min_value = 0
    slider.max_value = 1
    slider.value = sound_volume
    slider.value_changed.connect(_set_volume)
    menu.add_child(slider)
    _menu_button(menu,"بازگشت",0.62,Callable(self,"_show_menu"))

func _set_volume(v: float) -> void:
    sound_volume = v
    AudioServer.set_bus_volume_linear(master_bus,v)

func _start_game() -> void:
    game_started = true
    menu.visible = false
    get_tree().paused = false
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if not OS.has_feature("mobile") else Input.MOUSE_MODE_VISIBLE
    _message("صدای قدم‌ها رو دنبال نکن...",3.0)
    _save_progress()

func _continue_game() -> void:
    _load_progress()
    _start_game()

func _pause_game() -> void:
    if not game_started:
        return
    game_started = false
    menu.visible = true
    get_tree().paused = false
    _show_menu()

func _toggle_flashlight() -> void:
    if player:
        player.toggle_flashlight()

func _interact() -> void:
    if not game_started or not player:
        return
    var cam: Camera3D = player.get_node("Camera3D")
    var query := PhysicsRayQueryParameters3D.create(cam.global_position,cam.global_position-cam.global_basis.z*3.0)
    query.collide_with_areas = true
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _message("چیزی اینجا نیست.",1.2)
        return
    var obj: Object = hit.collider
    if obj.is_in_group("interactable"):
        if obj.has_method("interact"):
            obj.interact(self)
        elif obj.name == "FuseConsole":
            if keys_found >= 1:
                puzzle_solved = true
                _message("فیوز جا افتاد... قفل خروجی آزاد شد!",3.0)
                if exit_door:
                    exit_door.set("is_locked",false)
            else:
                _message("برای فعال‌کردن جعبه، اول فیوز را پیدا کن.",2.0)
        elif obj.has_method("open_door"):
            obj.open_door(self)
        else:
            _message("قفل است. باید راهی پیدا کنم.",2.0)

func collect_item(kind: String, label_text: String) -> void:
    if kind == "Key":
        keys_found += 1
        _message(label_text + " پیدا شد! (" + str(keys_found) + "/2)",2.0)
    elif kind == "Fuse":
        puzzle_solved = true
        _message("فیوز را پیدا کردی. حالا جعبه فیوز را فعال کن.",2.5)
    _save_progress()

func _message(t: String, duration := 2.0) -> void:
    message_label.text = t
    hint_timer = duration

func _process(delta: float) -> void:
    if hint_timer > 0:
        hint_timer -= delta
        if hint_timer <= 0:
            message_label.text = ""
    if hud and hud.get_node_or_null("Control/Status"):
        hud.get_node("Control/Status").text = "BLAST HORROR  |  کلیدها: %d/2" % keys_found

func enemy_caught_player() -> void:
    if not game_started:
        return
    scare_player.play()
    _message("پیدات کرد... این‌بار فرار کن!",2.5)
    player.global_position = Vector3(0,0.15,11.5)
    enemy.global_position = Vector3(-8,0.1,-10)
    _save_progress()

func finish_game() -> void:
    game_started = false
    menu.visible = true
    for c in menu.get_children():
        c.queue_free()
    var shade := ColorRect.new()
    shade.color = Color(0.005,0.006,0.01,0.96)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu.add_child(shade)
    var title := Label.new()
    title.text = "BLAST HORROR\nYOU ESCAPED"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    title.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    title.add_theme_font_size_override("font_size",42)
    title.add_theme_color_override("font_color",Color(0.8,0.12,0.08))
    menu.add_child(title)
    _menu_button(menu,"بازی دوباره",0.72,Callable(self,"_restart"))

func _restart() -> void:
    keys_found = 0
    puzzle_solved = false
    player.global_position = Vector3(0,0.15,11.5)
    enemy.global_position = Vector3(-8,0.1,-10)
    get_tree().reload_current_scene()

func _save_progress() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("progress","keys",keys_found)
    cfg.set_value("progress","puzzle",puzzle_solved)
    cfg.set_value("audio","volume",sound_volume)
    cfg.save("user://blast_horror_save.cfg")

func _load_progress() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://blast_horror_save.cfg") == OK:
        keys_found = int(cfg.get_value("progress","keys",0))
        puzzle_solved = bool(cfg.get_value("progress","puzzle",false))
        sound_volume = float(cfg.get_value("audio","volume",0.7))
        AudioServer.set_bus_volume_linear(master_bus,sound_volume)
