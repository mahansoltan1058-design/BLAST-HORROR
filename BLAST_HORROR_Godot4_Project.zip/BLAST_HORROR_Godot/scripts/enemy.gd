extends CharacterBody3D
var target: Node3D
var speed := 2.15
var gravity := 18.0
var alert_distance := 13.0
var attack_distance := 1.25
var wander_timer := 0.0
var wander_dir := Vector3.ZERO

func _physics_process(delta: float) -> void:
    if not target or not target.get_parent().game_started:
        velocity = Vector3.ZERO
        return
    var to_player := target.global_position - global_position
    to_player.y = 0
    var distance := to_player.length()
    var dir := Vector3.ZERO
    if distance < alert_distance:
        dir = to_player.normalized()
        speed = 3.15 if distance < 6.0 else 2.35
        if distance < attack_distance:
            target.get_parent().enemy_caught_player()
    else:
        wander_timer -= delta
        if wander_timer <= 0:
            wander_timer = randf_range(2.0,5.0)
            wander_dir = Vector3(randf_range(-1,1),0,randf_range(-1,1)).normalized()
        dir = wander_dir
        speed = 0.8
    velocity.x = dir.x * speed
    velocity.z = dir.z * speed
    if not is_on_floor():
        velocity.y -= gravity*delta
    else:
        velocity.y = 0
    if dir.length() > 0.1:
        look_at(global_position+dir,Vector3.UP)
    move_and_slide()
