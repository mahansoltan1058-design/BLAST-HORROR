extends StaticBody3D
var is_locked := false
var is_open := false
var opened := false

func interact(game: Node) -> void:
    if is_locked:
        if name == "BasementDoor" and game.keys_found >= 1:
            is_locked = false
        elif name == "ExitDoor" and game.puzzle_solved and game.keys_found >= 2:
            is_locked = false
        else:
            game._message("قفل شده... کلید یا راه دیگری لازم است.",2.0)
            return
    if not opened:
        opened = true
        var tween := create_tween()
        tween.tween_property(self,"rotation:y",rotation.y+deg_to_rad(92),0.45)
        game._message("در باز شد...",1.2)
        if name == "ExitDoor" and game.keys_found >= 2 and game.puzzle_solved:
            game.finish_game()
    else:
        var tween := create_tween()
        tween.tween_property(self,"rotation:y",rotation.y-deg_to_rad(92),0.45)
        opened = false
