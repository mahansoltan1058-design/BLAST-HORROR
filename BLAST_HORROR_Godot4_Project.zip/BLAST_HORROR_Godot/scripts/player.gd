extends CharacterBody3D
var game: Node
var speed := 3.8
var gravity := 18.0
var look_sensitivity := 0.0022
var pitch := 0.0
var flashlight_on := true
var touch_look_id := -1
var last_touch := Vector2.ZERO
var joystick_vector := Vector2.ZERO

@onready var camera: Camera3D = $Camera3D
@onready var flashlight: SpotLight3D = $Camera3D/Flashlight

func _ready() -> void:
    set_process_input(true)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        _look(event.relative)
    elif event is InputEventScreenTouch:
        if event.pressed and event.position.x > get_viewport().size.x * 0.38:
            touch_look_id = event.index
            last_touch = event.position
        elif not event.pressed and event.index == touch_look_id:
            touch_look_id = -1
    elif event is InputEventScreenDrag and event.index == touch_look_id:
        var delta := event.position - last_touch
        last_touch = event.position
        _look(delta * 0.75)

func _look(delta: Vector2) -> void:
    rotate_y(-delta.x * look_sensitivity)
    pitch = clamp(pitch - delta.y * look_sensitivity,-1.35,1.35)
    camera.rotation.x = pitch

func _physics_process(delta: float) -> void:
    if not game or not game.game_started:
        velocity = Vector3.ZERO
        return
    var input_dir := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    if has_node("../HUD/Control/VirtualJoystick"):
        var joy = get_node("../HUD/Control/VirtualJoystick")
        if joy.has_method("get_output"):
            var v: Vector2 = joy.get_output()
            if v.length() > 0.08:
                input_dir = v
    input_dir = input_dir.limit_length(1.0)
    var direction := (global_transform.basis * Vector3(input_dir.x,0,input_dir.y)).normalized()
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0
    move_and_slide()

func toggle_flashlight() -> void:
    flashlight_on = not flashlight_on
    flashlight.visible = flashlight_on
