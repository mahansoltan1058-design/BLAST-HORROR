extends Control
var finger_id := -1
var output := Vector2.ZERO
var knob := Vector2.ZERO
const RADIUS := 66.0

func _ready() -> void:
    custom_minimum_size = Vector2(180,180)
    mouse_filter = Control.MOUSE_FILTER_STOP

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and finger_id == -1:
            finger_id = event.index
            _update_stick(event.position)
        elif not event.pressed and event.index == finger_id:
            finger_id = -1
            output = Vector2.ZERO
            knob = Vector2.ZERO
            queue_redraw()
    elif event is InputEventScreenDrag and event.index == finger_id:
        _update_stick(event.position)

func _update_stick(p: Vector2) -> void:
    var center := size * 0.5
    var v := (p-center).limit_length(RADIUS)
    knob = v
    output = Vector2(v.x/RADIUS,-v.y/RADIUS)
    queue_redraw()

func get_output() -> Vector2:
    return output

func _draw() -> void:
    var center := size * 0.5
    draw_circle(center,RADIUS,Color(0.08,0.08,0.09,0.45))
    draw_arc(center,RADIUS,0,TAU,48,Color(0.75,0.75,0.78,0.55),3.0)
    draw_circle(center+knob,28,Color(0.72,0.72,0.76,0.65))
