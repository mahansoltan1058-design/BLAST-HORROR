extends Area3D
var item_type := "Key"
var display_name := "Key"
var collected := false

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
    # Keep items in the world until the player deliberately interacts.
    pass

func interact(game: Node) -> void:
    if collected:
        return
    collected = true
    game.collect_item(item_type,display_name)
    queue_free()
